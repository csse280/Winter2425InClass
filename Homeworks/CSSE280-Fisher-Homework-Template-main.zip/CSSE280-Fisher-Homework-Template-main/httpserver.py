print("TODO: replace httpserver.py with YOUR web server. Serve files from './public'")

